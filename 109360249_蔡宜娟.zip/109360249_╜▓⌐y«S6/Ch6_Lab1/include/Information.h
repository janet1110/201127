#include <stdio.h>
typedef struct _sPreson
{
	char name[8];
	int gender;
	int age;
}Person;